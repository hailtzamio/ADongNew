/* 
Copyright (c) 2020 Swift Models Generated from JSON powered by http://www.json4swift.com

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

For support, please feel free to contact me at https://www.linkedin.com/in/syedabsar

*/

import Foundation
struct Json4Swift_Base : Codable {
	let id : Int?
	let name : String?
	let teamSize : Int?
	let address : String?
	let addressFull : String?
	let phone : String?
	let phone2 : String?
	let workingStatus : String?
	let rating : Int?
	let createdTime : String?
	let updatedTime : String?
	let leaderId : Int?
	let leaderFullName : String?
	let projectId : String?
	let projectName : String?
	let futureProjectId : String?
	let futureProjectName : String?
	let provinceId : Int?
	let provinceName : String?
	let districtId : Int?
	let districtName : String?
	let createdById : Int?
	let createdByFullName : String?
	let updatedById : Int?
	let updatedByFullName : String?

	enum CodingKeys: String, CodingKey {

		case id = "id"
		case name = "name"
		case teamSize = "teamSize"
		case address = "address"
		case addressFull = "addressFull"
		case phone = "phone"
		case phone2 = "phone2"
		case workingStatus = "workingStatus"
		case rating = "rating"
		case createdTime = "createdTime"
		case updatedTime = "updatedTime"
		case leaderId = "leaderId"
		case leaderFullName = "leaderFullName"
		case projectId = "projectId"
		case projectName = "projectName"
		case futureProjectId = "futureProjectId"
		case futureProjectName = "futureProjectName"
		case provinceId = "provinceId"
		case provinceName = "provinceName"
		case districtId = "districtId"
		case districtName = "districtName"
		case createdById = "createdById"
		case createdByFullName = "createdByFullName"
		case updatedById = "updatedById"
		case updatedByFullName = "updatedByFullName"
	}

	init(from decoder: Decoder) throws {
		let values = try decoder.container(keyedBy: CodingKeys.self)
		id = try values.decodeIfPresent(Int.self, forKey: .id)
		name = try values.decodeIfPresent(String.self, forKey: .name)
		teamSize = try values.decodeIfPresent(Int.self, forKey: .teamSize)
		address = try values.decodeIfPresent(String.self, forKey: .address)
		addressFull = try values.decodeIfPresent(String.self, forKey: .addressFull)
		phone = try values.decodeIfPresent(String.self, forKey: .phone)
		phone2 = try values.decodeIfPresent(String.self, forKey: .phone2)
		workingStatus = try values.decodeIfPresent(String.self, forKey: .workingStatus)
		rating = try values.decodeIfPresent(Int.self, forKey: .rating)
		createdTime = try values.decodeIfPresent(String.self, forKey: .createdTime)
		updatedTime = try values.decodeIfPresent(String.self, forKey: .updatedTime)
		leaderId = try values.decodeIfPresent(Int.self, forKey: .leaderId)
		leaderFullName = try values.decodeIfPresent(String.self, forKey: .leaderFullName)
		projectId = try values.decodeIfPresent(String.self, forKey: .projectId)
		projectName = try values.decodeIfPresent(String.self, forKey: .projectName)
		futureProjectId = try values.decodeIfPresent(String.self, forKey: .futureProjectId)
		futureProjectName = try values.decodeIfPresent(String.self, forKey: .futureProjectName)
		provinceId = try values.decodeIfPresent(Int.self, forKey: .provinceId)
		provinceName = try values.decodeIfPresent(String.self, forKey: .provinceName)
		districtId = try values.decodeIfPresent(Int.self, forKey: .districtId)
		districtName = try values.decodeIfPresent(String.self, forKey: .districtName)
		createdById = try values.decodeIfPresent(Int.self, forKey: .createdById)
		createdByFullName = try values.decodeIfPresent(String.self, forKey: .createdByFullName)
		updatedById = try values.decodeIfPresent(Int.self, forKey: .updatedById)
		updatedByFullName = try values.decodeIfPresent(String.self, forKey: .updatedByFullName)
	}

}